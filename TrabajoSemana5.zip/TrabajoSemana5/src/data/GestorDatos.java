package data;

import model.Tour;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class GestorDatos {

    public ArrayList<Tour> cargarTours() {

        ArrayList<Tour> listaTours = new ArrayList<>();

        try {

            BufferedReader br = new BufferedReader(
                    new FileReader("src/resources/tours.txt"));

            String linea;

            while ((linea = br.readLine()) != null) {

                String[] datos = linea.split(";");

                if (datos.length == 3) {

                    String nombre = datos[0];
                    String tipo = datos[1];

                    try {

                        int precio = Integer.parseInt(datos[2]);

                        Tour tour = new Tour(nombre, tipo, precio);

                        listaTours.add(tour);

                    } catch (NumberFormatException e) {

                        System.out.println("Precio inválido: " + datos[2]);

                    }
                }
            }

            br.close();

        } catch (IOException e) {

            System.out.println("Error al leer archivo: " + e.getMessage());

        }

        return listaTours;
    }
}