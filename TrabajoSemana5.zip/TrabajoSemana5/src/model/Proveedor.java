package model;

public class Proveedor {

    private String nombre;
    private String servicio;

    public Proveedor(String nombre, String servicio) {
        this.nombre = nombre;
        this.servicio = servicio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getServicio() {
        return servicio;
    }

    public void setServicio(String servicio) {
        this.servicio = servicio;
    }

    @Override
    public String toString() {
        return nombre + " - " + servicio;
    }
}